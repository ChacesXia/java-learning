class One{
  private int i;
  public void set(int i){
    this.i=i;
  }
  public int get(){
    return this.i;
  }
}

