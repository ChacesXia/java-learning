import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.util.concurrent.*;

import static com.SwingConsole.SwingConsole;

class Demo extends JFrame{
  public Demo(){
    add(BorderLayout.NORTH,new JButton("��"));
    add(BorderLayout.CENTER,new JButton("��"));
  }
  public static void main (String[] args) {
    run(new Demo(),400,500);
  }
}