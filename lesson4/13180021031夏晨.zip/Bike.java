class Bike implements Vehicle{
  public void star (float f1) {
    System.out.println("The bike is star! it's current speed is : "+f1);
  }  
  public void stop (float f1) {
    System.out.println("The bike is star! it's speed reduce : "+f1);
  }
}