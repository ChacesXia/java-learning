class Interfacedemo {
  public static void main(String[] args) {
    Bike bike1 = new Bike();
    bike1.star(5);
    bike1.stop(3);

    Bus bus1 = new Bus();
    bus1.star(5);  
    bus1.stop(5);
  }
}